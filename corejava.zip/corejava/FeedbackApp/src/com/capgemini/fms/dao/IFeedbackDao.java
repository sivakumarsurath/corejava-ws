package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

public interface IFeedbackDao {
	
	
	Map<String, Integer> addFeedbackDetails(String name, int rating, String subject);
	Map<String, Integer> getFeedbackReport();
	
	
	
	
	

}
