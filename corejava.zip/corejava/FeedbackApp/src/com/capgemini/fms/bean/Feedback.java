package com.capgemini.fms.bean;

public class Feedback {
	
	private String TeacherName;
	private int Rating;
	private String Topic;
	public Feedback() {
		super();
	
	}
	public Feedback(String teacherName, int rating, String topic) {
		super();
		TeacherName = teacherName;
		Rating = rating;
		Topic = topic;
	}
	public String getTeacherName() {
		return TeacherName;
	}
	public void setTeacherName(String teacherName) {
		TeacherName = teacherName;
	}
	public int getRating() {
		return Rating;
	}
	public void setRating(int rating) {
		Rating = rating;
	}
	public String getTopic() {
		return Topic;
	}
	public void setTopic(String topic) {
		Topic = topic;
	}
	@Override
	public String toString() {
		return "Feedback [TeacherName=" + TeacherName + ", Rating=" + Rating + ", Topic=" + Topic + "]";
	}
	
	
	

}
