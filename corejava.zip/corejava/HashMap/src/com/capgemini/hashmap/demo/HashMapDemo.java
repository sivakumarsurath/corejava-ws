package com.capgemini.hashmap.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {}
	
	
	/*public static  ArrayList<String> getnames (HashMap<String, String> treeMap,String);
	
	ArrayList<String> arraylist =new ArrayList<>();
	Set
	
	
	
	
	treeMap.key
	
	public static void main(String[] args) {
		

	
	Map<String, String> namelist=new HashMap<>();

	namelist.put("siva" , "capgemini");
	namelist.put("kumar", "tcs");
	namelist.put("surath", "capgemini");
	namelist.put("ssk", "tcs");
	namelist.put("ss", "capgemini");
	 String org ='cg';
	 
	ArrayList<String> names=getnames(employees,org);
	for(String name)
	
	
	

}}
*/