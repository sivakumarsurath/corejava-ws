package com.capgemini.employeeinsurance.service;

public interface EmployeeService {

}
