package com.capgemini.employeeinsurance.bean;

    public class Employee {
	private int employeeId;
	private String name;
	private long Salary;
	private String designation;
	private String InsuranceScheme;
	public Employee() {
		super();
	}
	public Employee(int employeeId, String name, long salary, String designation, String insuranceScheme) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		Salary = salary;
		this.designation = designation;
		InsuranceScheme = insuranceScheme;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSalary() {
		return Salary;
	}
	public void setSalary(long salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return InsuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		InsuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", Salary=" + Salary + ", designation="
				+ designation + ", InsuranceScheme=" + InsuranceScheme + "]";
	}
	


}
