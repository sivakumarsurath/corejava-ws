package com.capgemini.employeeinsurance.dao;

import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.employeeinsurance.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	
	boolean status = false;
	Logger log = Logger.getLogger("EmployeeDAOImpl");

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteEmployee(int EmployeeId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee getEmployee(int EmployeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Integer, Employee> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
