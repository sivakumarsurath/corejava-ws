package com.capgemini.employeeinsurance.presentation;

import java.util.Scanner;

public class MainUI {
	
	public static void main(String[] args) {
		
		String continueChoice;
		
		boolean continueValue = false;
		
		Scanner scanner = null;
		do {
			System.out.println("****Welcome and Have a nice day****");
			System.out.println("1.Add Employee details");
			System.out.println("2.Get Employee details");
			System.out.println("3.exit");
		
			
			
			
		} while (continueValue);
		
		
	}
	
	
	
	

}
