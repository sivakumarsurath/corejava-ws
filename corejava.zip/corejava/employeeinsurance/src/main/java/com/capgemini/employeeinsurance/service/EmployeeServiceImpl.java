package com.capgemini.employeeinsurance.service;

public class EmployeeServiceImpl implements EmployeeService {

}
