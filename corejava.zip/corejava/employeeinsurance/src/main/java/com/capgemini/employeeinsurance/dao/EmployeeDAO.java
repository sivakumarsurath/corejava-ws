package com.capgemini.employeeinsurance.dao;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.employeeinsurance.bean.Employee;

public interface EmployeeDAO {

	Map<Integer, Employee> customerList = new HashMap<>();

	int addEmployee(Employee employee);

	boolean updateEmployee(Employee employee);

	boolean deleteEmployee(int EmployeeId);

	Employee getEmployee(int EmployeeId);

	Map<Integer, Employee> getEmployees();

}
