package com.cg.java.arm;

import java.util.Scanner;

public class ArmstrongNo {
	public static int checkingNumber(int array[]) {
		int remi = 0, sum = 0, count = 0;

		for (int i = 0; i < array.length; i++) {
			sum = 0;
			int n = array[i];
			remi = 0;
			while (array[i] > 0) {
				remi = array[i] % 10;
				sum = sum + (remi * remi * remi);
				array[i] = array[i] / 10;
			}
			if (sum == n) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("size");
		int size = scanner.nextInt();
		int array[] = new int[size];
		System.out.println("enter array elements");

		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
		int output = checkingNumber(array);
		System.out.println(output);
		scanner.close();
	}
}
