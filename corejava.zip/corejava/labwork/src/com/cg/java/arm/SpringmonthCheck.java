package com.cg.java.arm;

import java.util.Scanner;

public class SpringmonthCheck {

	static int day, month;

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println(" enter a month");
		int month = scanner.nextInt();
		System.out.println("enter a day");
		int day = scanner.nextInt();

		if (month == 3 || month == 4 || month == 5 || month == 6) {
			switch (month) {
			case 3: {
				if (day > 20)
					System.out.println("The user input is spring time");

			}
				break;
			case 4: {

				System.out.println("The user input is spring time");

			}
				break;

			case 5: {

				System.out.println("The user input is spring time");

			}
				break;
			case 6: {
				if (day < 20)
					System.out.println("The user input is spring time");

			}
				break;

			}
		} else
			System.out.println("The user input is not a spring time");

	}
}