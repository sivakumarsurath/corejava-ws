package com.capgemini.activity1.dao;

import java.util.HashMap;

import com.capgemini.activity1.bean.Product;
import com.capgemini.activity1.bean.Supplier;

public class SuperShoppeDAOImpl implements ISuperShoppeDAO {

	@Override
	public int addProduct(Product product) {
		
		return 0;
	}
	@Override
	public int addSupplier(Supplier sup) {
		
		return 0;
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		
		return null;
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		
		return null;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
	
	
}
