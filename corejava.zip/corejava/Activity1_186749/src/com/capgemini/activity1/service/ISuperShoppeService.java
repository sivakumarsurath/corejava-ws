package com.capgemini.activity1.service;

import java.util.HashMap;

import com.capgemini.activity1.bean.Product;
import com.capgemini.activity1.bean.Supplier;


public interface ISuperShoppeService {
	
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public HashMap<Integer, Product> getAllProducts();
	public HashMap<Integer,Supplier> getAllSuppliers();
	

	

}
