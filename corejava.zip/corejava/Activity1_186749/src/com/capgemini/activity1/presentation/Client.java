package com.capgemini.activity1.presentation;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.activity1.bean.Product;
import com.capgemini.activity1.service.SuperShoppeServiceImpl;

public class Client {
	
	static SuperShoppeServiceImpl service=new SuperShoppeServiceImpl();
	 static Scanner scanner=new Scanner(System.in);
	static void addProduct() throws Productdetails{
		System.out.println("enter product id");
		int productID=0;
		boolean flag=false;
		do {
			
			scanner=new Scanner(System.in);
			System.out.println("enter the id please");
			try {
				flag= true;
				productID= Scanner.nextInt();
				
			} catch (InputMismatchException e) {
				
				flag= false;
				System.err.println("please enter the digits only\n");
		
			}
			
		} while (!flag);
		
		System.out.println("enter product name");
		String name =scanner.next();
		System.out.println("enter product price");
		scanner.nextLine();
		double price =scanner.nextInt();
		
		System.out.println("enter quantity");
		int quantity=scanner.nextInt();
		if (!service.isQuantityValid(quantity)) {
			try {
				throw new ProductDetails1("product id should be in numbers only");
			} catch (ProductDetails1 e) {
				System.err.println(e.getMessage());
			}
		} else {
	 Product product= new Product(productID,name,price,quantity);
			int custId = service.addProduct(product);
			System.out.println("Product Registered successfully and your id is:" + custId);
			System.out.println("Namaskar Application m apka swagat hai");
		}
	}  
	public static void main(String[] args) {
		String option = null;
		do {
			System.out.println("1.Add Product\n2.Add Supplier\n3.display\n0.exitl");
			int choice = scanner.nextInt();
			switch (choice) {
			case 0:
				System.exit(0);
			case 1: {
				try {
					addProduct();
				} catch (ProductDetails1 e) {
				
					e.printStackTrace();
				}
			}
				break;
			case 5: {
				Map<Integer,Product>productList=service.getAllProducts();
				System.out.println(productList);
			}
				break;

			default:
				System.out.println("Enter 1 to 5 only");
				break;
			}
			System.out.println("Press y to continue");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));

		scanner.close();

	}


	}
