package com.capgemini.activity1.exception;

public class SuperShoppeException extends Exception {

	public SuperShoppeException(String message) {
		super(message);
	}

	
}
