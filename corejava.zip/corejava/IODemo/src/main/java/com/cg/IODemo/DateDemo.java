package com.cg.IODemo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

public class DateDemo {

	public static void main(String[] args) {

		Date d1 = new Date();
		System.out.println("current Date:  " + d1);

		Calendar c = Calendar.getInstance();
		System.out.println(c.get(Calendar.DATE) + "/"
				+ (c.get(Calendar.MONTH) + 1) + "/" + c.get(Calendar.YEAR));
		System.out.println("Time:" + c.get(Calendar.HOUR) + ":"
				+ c.get(Calendar.MINUTE) + ":" + c.get(Calendar.AM_PM));
		Date d2 = new Date(9788666448L);
		System.out.println(d2);
		System.out.println("d1>d2" + d1.after(d2));
		System.out.println("d1<d2" + d1.before(d2));
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.FULL,
				DateFormat.FULL, Locale.ENGLISH);
		System.out.println(df.format(d1));
		SimpleDateFormat sf = new SimpleDateFormat("dd-MM-yy");
		System.out.println(sf.format(d1));
		SimpleDateFormat sf1 = new SimpleDateFormat("dd/MMM/yyyy HH:mm");
		System.out.println(sf1.format(d1));
		Locale locale = Locale.getDefault();
		int amt = 898985;
		Currency cur = Currency.getInstance(locale);
		System.out.println("Currency Code:" + amt + cur.getCurrencyCode());
		System.out.println("Currency symbol:" + amt + cur.getSymbol());
		System.out.println("Currency name:" + amt + cur.getDisplayName());

	}
}