package com.capgemini.storingproducts.bean;

public class Supplier {
	
private int supplierId;
	
	private String name;
	
	private double mobileNo;
	
	private int address;

	public Supplier() {
		super();
		
	}

	public Supplier(int supplierId, String name, double mobileNo, int address) {
		super();
		this.supplierId = supplierId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.address = address;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(double mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", name=" + name + ", mobileNo=" + mobileNo + ", address="
				+ address + "]";
	}

}
