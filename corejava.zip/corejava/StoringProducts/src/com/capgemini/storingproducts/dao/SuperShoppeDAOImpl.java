package com.capgemini.storingproducts.dao;

import java.util.HashMap;
import java.util.function.Supplier;

import com.capgemini.storingproducts.bean.Product;

public class SuperShoppeDAOImpl implements ISuperShoppeDAO {
	
	HashMap<Integer,Product> products;
	HashMap<Integer,Supplier> Suppliers;
	@Override
	public int addProduct(Product product) {
	
		return 0;
	}
	@Override
	public int addSupplier(Supplier sup) {
		
		return 0;
	}
	@Override
	public HashMap<Integer, Product> getAllProducts() {
		
		return null;
	}
	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		
		return null;
	}
	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	

}
