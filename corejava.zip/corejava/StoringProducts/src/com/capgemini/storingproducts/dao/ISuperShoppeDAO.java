package com.capgemini.storingproducts.dao;

import java.util.HashMap;
import java.util.function.Supplier;

import com.capgemini.storingproducts.bean.Product;

public interface ISuperShoppeDAO {
	
	HashMap<Integer, Product>productList=new HashMap<>();
	HashMap<Integer, Supplier>supplierList=new HashMap<>();

	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	
	Product getProduct(int productId);
	public  HashMap<Integer, Product> getAllProducts();
	public  HashMap<Integer, Supplier> getAllSuppliers();
	
	
	
	
	
}
