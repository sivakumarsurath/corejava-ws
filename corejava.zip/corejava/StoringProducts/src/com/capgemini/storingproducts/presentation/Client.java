package com.capgemini.storingproducts.presentation;

public class Client {

}
