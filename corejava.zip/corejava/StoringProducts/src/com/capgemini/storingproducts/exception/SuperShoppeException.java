package com.capgemini.storingproducts.exception;

public class SuperShoppeException extends Exception{
	
	
	

	
	
	
}
