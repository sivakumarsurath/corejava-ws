package com.capgemini.storingproducts.service;

import java.util.HashMap;
import java.util.function.Supplier;
import com.capgemini.storingproducts.bean.Product;
import com.capgemini.storingproducts.exception.SuperShoppeException;

public interface ISuperShoppeService {
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public  HashMap<Integer, Product> getAllProducts();
	public  HashMap<Integer, Supplier> getAllSuppliers();
	boolean isproductNameValid(String name) throws  SuperShoppeException;
}
