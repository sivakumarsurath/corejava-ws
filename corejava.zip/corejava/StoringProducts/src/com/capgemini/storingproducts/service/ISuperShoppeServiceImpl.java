package com.capgemini.storingproducts.service;

import java.util.HashMap;
import java.util.function.Supplier;

import com.capgemini.storingproducts.bean.Product;
import com.capgemini.storingproducts.exception.SuperShoppeException;

public class ISuperShoppeServiceImpl implements ISuperShoppeService{

	@Override
	public int addProduct(Product product) {
		
		return 0;
	}

	@Override
	public int addSupplier(Supplier sup) {
		
		return 0;
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		
		return null;
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		
		return null;
	}

	@Override
	public boolean isproductNameValid(String name) throws SuperShoppeException {
		// TODO Auto-generated method stub
		return false;
	}
	

}
