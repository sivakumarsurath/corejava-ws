package com.capgemini;

public enum Gender {

	MALE,FEMALE;

	public static Iterable<Person> stream() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
	
}
