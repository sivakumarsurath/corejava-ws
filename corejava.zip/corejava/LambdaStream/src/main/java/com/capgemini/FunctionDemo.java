package com.capgemini;

import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;

public class FunctionDemo {

	public static void main(String[] args) {

		Function<Integer, Double> fun1 = (n) -> n / 3.0;
		System.out.println("25/3.0=>" + fun1.apply(25));
		BiFunction<Integer, Integer, Double> bifun = (x, y) -> x + y + 0.0;
		System.out.println("10+20=>" + bifun.apply(10, 20));
		// write a bifunction definition for biggest number of given number;
		// output statement should say 30 is biggest value.

		BiFunction<Integer, Integer, String> bifun1 = (x, y) -> x > y ? x + " is big" : y + "is big";
		System.out.println("10>20?" + bifun1.apply(10, 20));

		// Binary operator
		BinaryOperator<Integer> biopmultiply = (x, y) -> x * y;
		System.out.println(biopmultiply.apply(10, 20));
//predicate
		Predicate<Integer> oddcheck = (n) -> n % 2 != 0;
		System.out.println("13 is odd?=>" + oddcheck.test(13));
		System.out.println("20 is odd?=>" + oddcheck.test(20));
		// use predicate to eligibility for vote
		Predicate<Integer> vote = (n) -> n > 18;
		System.out.println("age is 23 =>" + (vote.test(23) ? "eligible for voting" : "not eligible for voting"));
		System.out.println("age is 13 =>" + (vote.test(13) ? "eligible for voting" : "not eligible for voting"));
		// use Bipredicate findminimum number
		BiPredicate<Integer, Integer> min = (a, b) -> a < b;
		System.out.println("10,20 minimum is:" + (min.test(10, 20) ? 10 : 20));

	}

}
