package com.capgemini;

public class GreetingClient {
  public static void main(String[] args) {
	Greeting greet1=new GreetingImpl();
	System.out.println(greet1.greet("siva"));
	
	//lambda Expression
	
	
	Greeting greet2=(name)->"from lambda -Welcome"+name;
	System.out.println(greet2.greet("siva"));
}
}
