package com.capgemini;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PersonStreamDemo {
	
	public static void main(String[] args) {
		
	List<Person> people=Arrays.asList(
			
			new Person ("siva",21,Gender.MALE),
			new Person ("kumar",22,Gender.MALE),
			new Person ("ssk",20,Gender.MALE),
			new Person ("surath",19,Gender.MALE),
			new Person ("savi",40,Gender.FEMALE),
			new Person ("siva s",16,Gender.MALE));
	
	//print all person details
		people.stream().forEach(System.out::println);
	
	//print all male names
		people.stream().filter(p->p.getGender().equals(Gender.MALE))
		.map(p->p.getName()).forEach(System.out::println);
	
	//print all males names uppercase and age>18
		people.stream().filter(p->p.getAge()>18)
		.filter(p->p.getGender().equals(Gender.MALE))
				.map(p->p.getName())
				.map(p->p.toUpperCase())
				.forEach(System.out::println);
	
		//print all males names uppercase and age>18 using method references for map
		
		
		
		
		
		
	}

}
