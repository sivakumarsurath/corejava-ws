package com.capgemini;

public interface Calculator {

	
	
	double operation(double a,double b);
	
	
}
