package com.capgemini;

public class GreetingImpl implements Greeting {

	public String greet(String name) {
		return "From Normal - Welcome"+name; 
	}

}
