package com.cg;

public class PrintThread implements Runnable {

	String s1, s2;
	TwoString twoString;

	public PrintThread() {
		super();

	}

	public PrintThread(String s1, String s2, TwoString twoString) {
		super();
		this.s1 = s1;
		this.s2 = s2;
		this.twoString = twoString;
		Thread t = new Thread(this);
		t.start();
	}

	public void run() {
		;
		twoString.display(s1, s2);
	}

	public static void main(String[] args) {
		TwoString ts = new TwoString();
		new PrintThread("Hello", "priya", ts);
		new PrintThread("How", "are you?", ts);
		new PrintThread("Bye", "Thankyou.......", ts);

	}
}