package com.cg;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorMain {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		/*
		 * MyTask task=new MyTask(); Thread t=new Thread(task); t.start();
		 * ExecutorService es= Executors.newSingleThreadExecutor();
		 */
		//ExecutorService es= Executors.newFixedThreadPool(3);
		ExecutorService es= Executors.newCachedThreadPool();
		es.execute(new MyTask());
		es.execute(new MyTask());
		es.execute(new MyTask());
		es.execute(new MyTask());
		Future f=es.submit(new MyTask());
		System.out.println("Result:"+f.get());
	
		System.out.println("Is finished:"+f.isDone());
	}

}
