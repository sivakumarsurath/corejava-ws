/*
 * package com.capgemini;
 * 
 * public class ThreadActivity extends Thread{
 * 
 * public void run() {
 * 
 * public static void main (String[] args) {
 * 
 * } String name=null; for (int i = 1; i <= 10; i++) {
 * 
 * System.out.println(Thread.currentThread().getName() + " is " + name + "==> "
 * + i); try { Thread.sleep(1000); } catch (InterruptedException e) {
 * 
 * e.printStackTrace();
 * 
 * }
 * 
 * }}}
 */