package com.capgemini.client;

import com.capgemini.MyThread;

public class MyThreadClient {
	public static void main(String[] args) {
		System.out.println(Thread.currentThread());
		MyThread thread1 = new MyThread("one");
		thread1.setName("First");

		MyThread thread2 = new MyThread("two");
		thread2.setName("Second");
		MyThread thread3 = new MyThread("three");
		thread3.setName("Third");

		// thread3.setPriority(Thread.MAX_PRIORITY);
		// thread1.setPriority(Thread.MIN_PRIORITY);

		thread1.start();
		try {
			thread1.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
		thread2.start();
		thread3.start();

	}
}