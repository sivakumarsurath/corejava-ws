package com.cg;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

class NumberStringCheckTest {
	static NumberStringCheck nsc;
	int n;
	String s;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		nsc = new NumberStringCheck();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		nsc = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		n = 99;
		s = "";
	}

	@AfterEach
	void tearDown() throws Exception {
		n = 0;
		s = "";
	}

	@Test
	void testIsOdd() {
		assertTrue(nsc.isOdd(n));
	}

	@Test
	void testIsOddNegative() {
		assertFalse(nsc.isOdd(8));
	}

	@Test
	void testIsBlank() {
		assertTrue(nsc.isBlank(s));
	}

	@Test
	void testIsBlankNegative() {
		assertFalse(nsc.isBlank("Siva"));
	}

	@ParameterizedTest
	@ValueSource(ints = { 1, 5, 99, 111, 545, 12545, 545, -45531, -697 })
	void testIsOddParameter(int n) {
		assertTrue(nsc.isOdd(n));
	}

	@ParameterizedTest
	@ValueSource(strings = {"","   " })
	void testIsBlankParameter(String s) {
		assertTrue(nsc.isBlank(s));
	}

	@ParameterizedTest
	@CsvFileSource(resources = "/data.csv")
	public void testCSVfile(String input, String expected) {
		assertEquals(expected, input.toUpperCase());
	}

}