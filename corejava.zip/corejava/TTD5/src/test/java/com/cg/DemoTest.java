package com.cg;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.RepeatedTest;

public class DemoTest {
 
	@Test
	public void m1(){
		System.out.println("Test m1()");
		
		
	}
	@Disabled
	@Test
	public void m2(){
		System.out.println("Test m2()");
		
}

	@Test
	@RepeatedTest(2)
	public void m3(){
		assertTrue(1==1);
		System.out.println("Test m3()");
		}
	}