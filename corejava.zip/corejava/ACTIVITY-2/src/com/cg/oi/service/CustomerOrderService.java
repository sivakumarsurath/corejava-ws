package com.cg.oi.service;

import java.util.List;

import com.cg.oi.Oiexception.OIException;
import com.cg.oi.beans.Item;
import com.cg.oi.beans.Order;

public interface CustomerOrderService {
	boolean addToCart(Order item)throws OIException;
	List<Order> printOrderedItems()throws OIException;
	public List<Item> getItems()throws OIException;
	boolean validateName(String name)throws OIException;
	boolean validatPhone(String phone)throws OIException;
	int OrderId()throws OIException;
	
	

}
