package com.cg.oi.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.oi.Dao.ItemDAO;
import com.cg.oi.Dao.ItemDAOImpl;
import com.cg.oi.Oiexception.OIException;
import com.cg.oi.beans.Item;
import com.cg.oi.beans.Order;

public class CustomerOrderServiceImpl implements CustomerOrderService {
	ItemDAO dao = new ItemDAOImpl();
	List<Order> list1 =new ArrayList<Order>();
	double Amount;

	@Override
	public boolean addToCart(Order item) throws OIException {
		
		list1.add(item);
		return true;
	}

	@Override
	public List<Order> printOrderedItems() throws OIException {
	
		return list1;
		
	}

	@Override
	public List<Item> getItems() throws OIException {
		
		Collection<Item> collection = null;
		try {
			collection = dao.getItems().values();
		} catch (OIException e) {

			e.printStackTrace();
		}
		List<Item> list = new ArrayList<>();
		list.addAll(collection);
		return list;
		
	}

	@Override
	public boolean validateName(String name) throws OIException {
	
		boolean validName = false;
		String regExName = "[A-Z]{1}[a-zA-Z]{4,}";
		if (!Pattern.matches(regExName, name)) {
			validName = true;
			throw new OIException("first letter should be capital and it must contain 5 letters atleast");
		}
		return validName;
	}

	@Override
	public boolean validatPhone(String phone) throws OIException {
		
		boolean validPhone = false;
		String regExPhone = "[7-9]{1}[0-9]{9}";
		if (!Pattern.matches(regExPhone, phone)) {
			validPhone = true;
			throw new OIException("Entered phone number is invalid");

		}
		return validPhone;
	}

	@Override
	public int OrderId() throws OIException {
		
		return dao.orderId();
	}

	
	
	

}
