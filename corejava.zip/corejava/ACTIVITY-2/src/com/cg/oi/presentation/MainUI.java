package com.cg.oi.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import com.cg.oi.service.CustomerOrderService;
import com.cg.oi.service.CustomerOrderServiceImpl;
import com.cg.oi.Oiexception.OIException;
import com.cg.oi.beans.Item;
import com.cg.oi.beans.Order;

/**
 * 
 * @author ssurath
 *
 */
   public class MainUI {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		CustomerOrderService service = new CustomerOrderServiceImpl();
		Scanner scanner = null;
		List<Item> list = null;
		boolean choiceFlag = false;
		String continuechoice;
		String continuechoice1;
		boolean continueFlag = false;
		boolean continueFlag1 = false;
		List<Order> list1 = new LinkedList<>();
		do {
			System.out.println("1. Register \n 2. Exit\n");
			System.out.println("Enter choice:");

			try {
				scanner = new Scanner(System.in);
				int choice = scanner.nextInt();

				switch (choice) {
				case 1: {
					boolean validateName = false;
					boolean validPhone = false;

					String name;
					String phone;
					do {
						System.out.println("enter name");
						name = scanner.next();
						try {
							service.validateName(name);
							validateName = true;
						} catch (OIException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							System.err.println("Enter valid name");
							validateName = false;
						}
					} while (!validateName);
					do {
						System.out.println("enter phone");
						phone = scanner.next();
						try {
							service.validatPhone(phone);
							validPhone = true;
						} catch (OIException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							System.err.println("Enter valid phone number");
							validPhone = false;
						}
					} while (!validPhone);
					if ((validateName == true) && (validPhone)) {
						System.out.println("registered sucessfully");
						boolean continueF = false;
						do {

							System.out.println(" 1. place the order \n 2. display cart");
							System.out.println("Enter choice :");
							int choice1 = 0;

							try {
								choice1 = scanner.nextInt();
								continueF = true;
								switch (choice1) {
								case 1: {
									double price = 0.00;
									double amnt = 0;

									try {
										/**
										 * calling getItems method using service object
										 */
										list = service.getItems();
										System.out.println(list);
										System.out.println("Enter Item id");
										int id = scanner.nextInt();
										System.out.println("enter quantity");
										int quantity = scanner.nextInt();
										int orderId = service.OrderId();
										System.out.println("order placed with orderId:" + orderId);
										Iterator<Item> iterator = list.iterator();
										while (iterator.hasNext()) {

											Item item = iterator.next();
											int Id = item.getItemId();
											if (id == Id) {
												price = item.getPrice();
												amnt = price * quantity;
											}

										}

										Order order = new Order(orderId, price, id, quantity, amnt);
										service.addToCart(order);

									} catch (OIException e) {

										e.printStackTrace();
									}
								}
									break;
								case 2: {
									try {

										double sum = 0;
										list1 = service.printOrderedItems();
										Iterator<Order> iterator = list1.iterator();
										while (iterator.hasNext()) {
											Order order = iterator.next();
											double amnt = order.getAmnt();
											sum = sum + amnt;

										}

										System.out.println(list1 + "\n" + "total amount is" + sum);
									} catch (OIException e) {

										e.printStackTrace();
									}

								}
									break;

								default: {
									System.out.println("enter 1 or 2");
									continueF = false;
								}
									break;
								}

								do {
									System.out.println("do u want to continue yes or no");
									continuechoice1 = scanner.next();
									if (continuechoice1.equals("yes")) {
										continueFlag1 = false;
										continueF = false;
										break;
									} else if (continuechoice1.equals("no")) {
										continueFlag1 = false;
										continueF = true;
										break;
									} else {
										System.out.println("enter yes or no");
										continueFlag1 = true;

									}
								} while (continueFlag1);
							} catch (InputMismatchException e) {
								System.err.println("please enter digits");
								continueF = false;
							}

						} while (!continueF);

					}
				}

					break;
				case 2: {
					System.exit(0);
					choiceFlag = false;

				}
					break;

				default: {
					System.err.println("please enter 1 or 2");
					choiceFlag = true;
				}
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("enter digits");
			}
		} while (choiceFlag);
	}
}
