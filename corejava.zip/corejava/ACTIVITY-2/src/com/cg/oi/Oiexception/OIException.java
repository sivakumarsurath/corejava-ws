package com.cg.oi.Oiexception;

public class OIException extends Exception {
	public OIException(String message) {
		super(message);
	}

}