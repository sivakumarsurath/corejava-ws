package com.cg.oi.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.oi.beans.Item;

public class ItemRepositories {
	public static Map<Integer, Item> itemList=new HashMap<>();
	static {
		itemList.put(12, new Item(12,"Pen",10000));
		itemList.put(13, new Item(13,"Laptop",40000));
		itemList.put(11, new Item(11,"Mobile",20000));
		itemList.put(14, new Item(14,"Computer",30000));
	}
	

}
