package com.cg.service;

public class CalculatorClass {
	public int add(int a, int b) {
		return a + b;
	}

	public int sub(int a, int b) {
		return a - b;
	}

	public int mul(int a, int b) {
		return a * b;
	}

	public int div(int a, int b) {
		return a / b;
	}

	public Object showObject() {
		return new Object();
	}

	public void display() {
		for (int i = 0; i < 1000; i++) {
			System.out.println(i);
		}
	}

}
