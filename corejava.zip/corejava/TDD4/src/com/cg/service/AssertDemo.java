package com.cg.service;

import java.util.Scanner;

public class AssertDemo {
	// assert(condition):message
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		assert(n>0):" n should be +ve value";
		System.out.println("Entered value is:"+n);
		

	}
		
	}


