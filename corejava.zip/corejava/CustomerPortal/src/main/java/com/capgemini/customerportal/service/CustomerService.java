package com.capgemini.customerportal.service;

import java.util.List;
import java.util.Map;

import com.capgemini.customerportal.bean.Customer;
import com.capgemini.customerportal.exception.CustomerPortalException;

public interface CustomerService {


	int add(Customer customer);

	boolean update(Customer customer) throws CustomerPortalException;

	boolean delete(int customerId) throws CustomerPortalException;

	Customer getCustomer(int customerId);

	List<Customer> getCustomers();
	
	
	
	
}
