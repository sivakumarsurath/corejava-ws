package com.capgemini.customerportal.bean;

public class Customer {

	private int customerId;
	private String name;
	private String address;
	private long mobile;

	public Customer() {
		super();
		
	}

	public Customer(int customerId, String name, String address, long mobile) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.mobile = mobile;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Customer customerId=" + customerId + ", name=" + name + ", address=" + address + ", mobile=" + mobile
				+ "";
	}

}
