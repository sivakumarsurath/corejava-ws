package com.capgemini.customerportal.presentation;

import java.util.List;
import java.util.Scanner;
import com.capgemini.customerportal.bean.Customer;
import com.capgemini.customerportal.exception.CustomerPortalException;
import com.capgemini.customerportal.service.CustomerService;
import com.capgemini.customerportal.service.CustomerServiceImpl;
/**
 * 
 * @author ssurath
 *@version 1.0
 *This is a MainUI Class taking the user inputs
 */
public class MainUI {
	/**
	 * 
	 * @param args
	 * @throws CustomerPortalException
	 */
	public static void main(String[] args) throws CustomerPortalException {
		/**
		 *CustmerService object initialized to call service method 
		 */
		CustomerServiceImpl service = new CustomerServiceImpl();
		/**
		 * scanner is created to take inputs 
		 */
		Scanner scanner = new Scanner(System.in);
		String option = null;
		do {
			System.out.println("1.Add\n 2.Update\n 3.Delete\n 4.ViewbyId\n 5.ViewAll\n 0.Exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 0:
				System.exit(0);
			case 1: {
				System.out.println("Enter Name");
				String name = scanner.next();
				System.out.println("Enter Address");
				String address = scanner.next();
				System.out.println("Enter Phone");
				long phone = scanner.nextLong();
				if (!service.isNameValid(name) || !service.isPhoneValid(phone))
					try {
						throw new CustomerPortalException(" invalid credentials");

					} catch (CustomerPortalException e) {
						System.err.println(e.getMessage());
					}
				else {
					Customer customer = new Customer(0, name, address, phone);
					int custId = service.add(customer);
					System.out.println("Customer registered successfully and your id is:" + custId);
				}
			}
				break;
			case 2: {
				System.out.println("Enter customer Id to update");
				int custId = scanner.nextInt();
				System.out.println("Enter name");
				String name = scanner.next();
				System.out.println("Enter Address");
				String address = scanner.next();
				System.out.println("Enter Phone");
				long phone = scanner.nextLong();
				Customer customer = new Customer(custId, name, address, phone);
				try {
					boolean status = service.update(customer);
					if (status) {
						System.out.println("Updated successfully");
					}
				} catch (CustomerPortalException e) {
					System.out.println(e.getMessage());
				}
			}
				break;

			case 3: {
				System.out.println("Enter Customer id to delete");
				int custId = scanner.nextInt();
				try {
					boolean status = service.delete(custId);
					if (status) {
						System.out.println(custId + "deleted successfully");
					}
				} catch (CustomerPortalException e) {
					System.out.println(e.getMessage());
				}
			}
				break;

			case 4: {

				System.out.println("Enter Customer id to view");
				int custId = scanner.nextInt();
				Customer c = service.getCustomer(custId);
				System.out.println(c);

			}
				break;

			case 5: {
				List<Customer> customerlist = service.getCustomers();
				System.out.println(customerlist);
			}
				break;
			default:
				System.out.println("Enter 1 to 5 only");
			}
			System.out.println("press y to continue");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));
		scanner.close();
	}
}
