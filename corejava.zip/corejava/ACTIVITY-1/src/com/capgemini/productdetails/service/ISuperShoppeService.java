package com.capgemini.productdetails.service;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.productdetails.bean.Product;
import com.capgemini.productdetails.bean.Supplier;
import com.capgemini.productdetails.exception.ProductDetails1;

public interface ISuperShoppeService {
	public int addProduct(Product product);
	public int addSupplier(Supplier supplier);
	public HashMap<Integer, Product> getAllProducts();
	public HashMap<Integer,Supplier> getAllSuppliers();
	boolean isproductNameValid(String name) throws  ProductDetails1;
	


}
