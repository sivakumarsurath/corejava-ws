package com.capgemini.productdetails.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.capgemini.productdetails.bean.Product;
import com.capgemini.productdetails.bean.Supplier;
import com.capgemini.productdetails.exception.ProductDetails1;
import com.capgemini.productdetails.service.SuperShoppeServiceImpl;

public class Client {
	static SuperShoppeServiceImpl service = new SuperShoppeServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	static void addProduct() throws Exception {
		System.out.println("Enter product id ");
		int productID = 0;
		boolean flag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter id:");
			try {
				flag = true;
				productID = scanner.nextInt();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		String name = null;
		flag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter product name");
			name = scanner.nextLine();
			try {

				flag = service.isproductNameValid(name);
				if (!flag)
					throw new ProductDetails1("Invalid Name Entered");

			} catch (ProductDetails1 e) {
				System.err.println(e.getMessage());
			}

		} while (!flag);

		double price = 0;

		do {
			System.out.println("Enter product price");
			scanner = new Scanner(System.in);

			try {
				flag = true;
				price = scanner.nextDouble();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		int quantity = 0;
		do {
			System.out.println("enter quantity");
			scanner = new Scanner(System.in);

			try {
				flag = true;
				quantity = scanner.nextInt();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		Product product = new Product(productID, name, price, quantity);
		int custId = service.addProduct(product);
		System.out.println("Product Registered successfully and your id is:" + custId);
		System.out.println("Welcome to Application ");

	}

	static void addSupplier() throws Exception {
		System.out.println("Enter supplier id ");
		int supplierID = 0;
		boolean flag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter pid:");
			try {
				flag = true;
				supplierID = scanner.nextInt();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		String name = null;
		flag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter supplier name");
			name = scanner.nextLine();
			try {

				flag = service.isproductNameValid(name);
				if (!flag)
					throw new ProductDetails1("Invalid Name Entered");

			} catch (ProductDetails1 e) {
				System.err.println(e.getMessage());
			}

		} while (!flag);

		double mobile = 0;

		do {
			System.out.println("Enter mobile no");
			scanner = new Scanner(System.in);

			try {
				flag = true;
				mobile = scanner.nextDouble();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		String address = null;
		do {
			System.out.println("enter address");
			scanner = new Scanner(System.in);

			try {
				flag = true;
				address = scanner.nextLine();
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("enter digits only\n");
			}

		} while (!flag);

		Supplier supplier = new Supplier(supplierID, name, mobile, address);
		int custId = service.addSupplier(supplier);
		System.out.println("Product Registered successfully and your id is:" + custId);
		System.out.println("Welcome to our Application");

	}

	public static void main(String[] args) throws Exception {

		String option = null;
		do {
			System.out.println("1.Add Product\n2.Add Supplier\n3.display products\n4.display Supplier\n0.exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 0:
				System.exit(0);
			case 1: {
				try {
					addProduct();
				} catch (ProductDetails1 e) {

					e.printStackTrace();
				}
			}
				break;

			case 2: {
				try {
					addSupplier();
				} catch (ProductDetails1 e) {

					e.printStackTrace();
				}
			}
				break;

			case 3: {
				HashMap<Integer, Product> productList = service.getAllProducts();
				System.out.println(productList);
			}
				break;
			case 4: {
				HashMap<Integer, Supplier> supplierList = service.getAllSuppliers();
				System.out.println(supplierList);
			}
				break;

			default:
				System.out.println("Enter 1 to 5 only");
				break;
			}
			System.out.println("Press y to continue");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));
		
		scanner.close();

	}

}
