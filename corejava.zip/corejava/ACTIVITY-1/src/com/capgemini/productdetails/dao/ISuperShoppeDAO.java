package com.capgemini.productdetails.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.productdetails.bean.Product;
import com.capgemini.productdetails.bean.Supplier;

public interface ISuperShoppeDAO {
	HashMap<Integer, Product>productList=new HashMap<>();
	HashMap<Integer, Supplier>supplierList=new HashMap<>();
   
	int addProduct(Product product);
	int addSupplier(Supplier sup);
	Product getProduct(int productId);
public HashMap<Integer, Product> getAllProducts();

public HashMap<Integer, Supplier> getAllSuppliers();



}
