package com.capgemini.mobshop.util;

import java.util.Comparator;
import com.capgemini.mobshop.dto.Mobiles;
public class MobileByName implements Comparator<Mobiles>{
	
public int compare(Mobiles mobile1, Mobiles mobile2) {
			
		return mobile1.getName().compareTo(mobile2.getName());
	}

}
