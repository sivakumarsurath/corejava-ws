package com.capgemini.mobshop.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.capgemini.mobshop.dao.MobileDAO;
import com.capgemini.mobshop.dao.MobileDAOImpl;
import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;
import com.capgemini.mobshop.util.MobileById;
import com.capgemini.mobshop.util.MobileByName;
import com.capgemini.mobshop.util.MobileByPrice;
/***
 * service implementation package
 * @author ssurath
 *
 */

public class MobileServiceImpl implements MobileService{
	/**
	 * It is service implementation layer having method implementation
	 */
MobileDAO dao=new MobileDAOImpl() ;
List<Mobiles> mobilelistbyname=new ArrayList<Mobiles>();
	public List<Mobiles> getMobileList() throws MobilesException{
		
		return dao.getMobileList();
	}

	public Mobiles deleteMobile(int mobcode) throws MobilesException {
		
		return dao.deleteMobile(mobcode);
	}

	public List<Mobiles> SortList(int criteria)throws MobilesException {
		// TODO Auto-generated method stub
		if(criteria==1)
		{
			mobilelistbyname=dao.getMobileList();
			Collections.sort(mobilelistbyname, new MobileByName());
		}
		if(criteria==2) {
			mobilelistbyname=dao.getMobileList();
			Collections.sort(mobilelistbyname, new MobileByPrice());
		}
		if(criteria==3) {
			mobilelistbyname=dao.getMobileList();
			Collections.sort(mobilelistbyname, new MobileById());
		}
		return mobilelistbyname;
	}

	public List<Mobiles> getList() throws MobilesException {
		// TODO Auto-generated method stub
		return dao.getList();
	}
	

}
