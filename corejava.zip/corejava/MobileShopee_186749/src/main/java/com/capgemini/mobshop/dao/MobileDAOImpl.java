package com.capgemini.mobshop.dao;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;
import com.capgemini.mobshop.util.Util;
/**
 * dao implementation package
 * @author ssurath
 *
 */

public class MobileDAOImpl implements MobileDAO{
	/**
	 * this is dao implementation layer
	 */

	public static Map<Integer,Mobiles> map=new HashMap<Integer, Mobiles>();
	Mobiles mob=new Mobiles();
	 List<Mobiles> list= new ArrayList<Mobiles>();
	public Mobiles deleteMobile(int mobcode) throws MobilesException {
		 
		
         if(map.containsKey(mobcode)) {
        	
             map.remove(mobcode);
           
         }
         else {
             try {
                 throw new MobilesException("Id does not exists");
             } catch (MobilesException e) {
                 System.out.println(e.getMessage());
             }
         }
        
         Iterator<Mobiles> iterator=map.values().iterator();
         while(iterator.hasNext()) {
        	 mob=iterator.next();
        	 list.add(mob);
         }
		
         return mob;
	}
	public List<Mobiles> getMobileList() throws MobilesException {
		// TODO Auto-generated method stub
		map=Util.getMobileEntries();
		  Collection<Mobiles> collection=map.values();
          List<Mobiles> mobiles=new ArrayList<Mobiles>();
          mobiles.addAll(collection);
          
		return mobiles;
	}
	public List<Mobiles> getList() throws MobilesException {
		// TODO Auto-generated method stub
		return list;
	}
	

}
