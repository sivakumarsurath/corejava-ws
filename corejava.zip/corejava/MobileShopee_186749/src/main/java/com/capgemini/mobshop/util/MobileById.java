package com.capgemini.mobshop.util;

import java.util.Comparator;

import com.capgemini.mobshop.dto.Mobiles;

public class MobileById implements Comparator<Mobiles>{


	public int compare(Mobiles mobile1, Mobiles mobile2) {
		if( mobile1.getMobileId()> mobile2.getMobileId())
			return 1;
		else if( mobile1.getMobileId()< mobile2.getMobileId())
			return -1;
		else
			return 0;
	}

	
}
