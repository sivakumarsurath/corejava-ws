package com.capgemini.mobshop.dto;
//This package contains the all bean class variables


public class Mobiles implements Comparable<Mobiles>{
	 private int mobileId;
	 private String name;
	 private double price;
	 private int quantity;
	public Mobiles() {
		super();
		
	}
	public Mobiles(int mobileId, String name, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity + "\n";
	}
	public int compareTo(Mobiles arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	 
	 

}
