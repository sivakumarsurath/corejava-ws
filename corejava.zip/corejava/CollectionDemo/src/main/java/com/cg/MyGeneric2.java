package com.cg;

public class MyGeneric2<T1, T2> {

	public void display(T1 a, T2 b) {
		System.out.println("A=" + a);
		System.out.println("B=" + b);
	}

	public static void main(String[] args) {
		MyGeneric2<Integer, Integer> mg1 = new MyGeneric2<>();
		mg1.display(10, 22);
		MyGeneric2<Integer, Float> mg2 = new MyGeneric2<>();
		mg2.display(10, 22.525f);
		MyGeneric2<String, Double> mg3 = new MyGeneric2<>();
		mg3.display("siva", 22.36);

	}
}