package com.cg;

public class MyGeneric3<T extends Number> {
	public void display(T a, T b) {

		System.out.println("A=" + a);
		System.out.println("B=" + b);
	}

	public static void main(String[] args) {
		MyGeneric3<Integer> mg1 = new MyGeneric3<>();
		mg1.display(10, 22);
		MyGeneric3<Double> mg2 = new MyGeneric3<>();
		mg2.display(10.53, 22.525);
		// it allows only subclass of number class
		// MyGeneric3<String> mg3=new MyGeneric3<>();
		// mg3.display("siva",22.36);
	}
}