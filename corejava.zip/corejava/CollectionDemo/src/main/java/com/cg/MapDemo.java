package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import com.sun.xml.internal.stream.buffer.sax.Properties;

public class MapDemo {

	public static void main(String[] args) {

		HashMap<Integer, String> map = new HashMap<>();
		//LinkedHashMap<Integer,String> map=new LinkedHashMap<>();
		//TreeMap<Integer,String> map=new TreeMap<>();
		//Hashtable<Integer,String> map=new Hashtable<>();
		//Properties map=new Properties();
		map.put(6, "java");
		map.put(2, "cpp");
		map.put(4, "ai");
		map.put(8, "python");
		map.put(6, "java");
		map.put(5, "html");

		System.out.println(map.size());
		System.out.println(map);
		System.out.println(map.remove(6));
		System.out.println("after remove");
		System.out.println(map);
//set of values
		Set<Integer> set =map.keySet();
		for (Integer k : set) {
			System.out.println(map.get(k));
		}
	
	Collection<String> collection=map.values();
	List<String> list=new ArrayList<String>();
	list.addAll(collection);
	System.out.println("list of values");
	System.out.println(list);
		
		
	}

}
