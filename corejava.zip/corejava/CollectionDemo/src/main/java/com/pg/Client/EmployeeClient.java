package com.pg.Client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

import com.cg.Service.NameSort;
import com.cg.Service.SalarySort;
import com.cg.beans.Employee;

public class EmployeeClient {

	public static void main(String[] args) {
		// ArrayList<Employee> emplist = new ArrayList<>();
		// HashSet<Employee> emplist = new HashSet<>();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Enter 1.EmpId-sort 2.Name-sort 3.Salary-sort");
			int option = scanner.nextInt();

			TreeSet<Employee> emplist = null;
			if (option == 1) {
				emplist = new TreeSet<>();
			} else if (option == 2) {
				emplist = new TreeSet<>(new NameSort());
			} else if (option == 3) {
				emplist = new TreeSet<>(new SalarySort());
			} else {
				System.out.println("invalid choice");
				System.exit(0);
			}

			Employee employee1 = new Employee(123, "siva", 50000, "analyst");
			Employee employee2 = new Employee(125, "kumar", 90000, "software");
			Employee employee3 = new Employee(127, "surath", 1000000, "ceo");
			Employee employee4 = new Employee(129, "ssk", 705000, "trainer");
			Employee employee5 = new Employee(123, "siva", 50000, "analyst");
			emplist.add(employee1);
			emplist.add(employee2);
			emplist.add(employee3);
			emplist.add(employee4);
			emplist.add(employee5);
			System.out.println(emplist);
		}

	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

}
