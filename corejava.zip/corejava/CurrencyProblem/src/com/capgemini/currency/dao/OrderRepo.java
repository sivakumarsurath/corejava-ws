package com.capgemini.currency.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.currency.bean.Order;

public interface OrderRepo {
	Map<Integer, Order> Currency=new HashMap<>();
	
	
	
	
	
	

}
