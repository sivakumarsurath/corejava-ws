package com.capgemini.currency.dao;

public class OrderRepoImpl implements OrderRepo{

}
