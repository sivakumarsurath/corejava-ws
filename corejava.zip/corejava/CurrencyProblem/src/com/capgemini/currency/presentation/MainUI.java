package com.capgemini.currency.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import com.capgemini.currency.bean.Order;
import com.capgemini.currency.exception.CurrencyException;
import com.capgemini.currency.service.OrderService;
import com.capgemini.currency.service.OrderServiceImpl;

public class MainUI{

	public static void main(String[] args) throws CurrencyException {
		
		String continueChoice;
		boolean continueValue = false;
		
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		OrderService orderService=new OrderServiceImpl();
		Map<Integer, Order> order=new HashMap<>();
		
		boolean flag=false;
		
		do {

			System.out.println("*** welcome to Currency Converter Application");
			System.out.println("1.Add details");			
			System.out.println("2.display all details");			
			System.out.println("3.exit");
			OrderService orderservice=new OrderServiceImpl();
			
			int choice = 0;
			boolean choiceFlag = false;
		
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					
					switch (choice) {

					case 1:
						boolean PriceFlag = false;
						double   Price= 0;
						do {
							
							scanner = new Scanner(System.in);
							System.out.println("enter the price you want");
							 Price = scanner.nextDouble();
						
						} while (!PriceFlag);
						
						int quantity=0;
						boolean quantityFlag= false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the Quantity you want:");
							
							try {
								quantity = scanner.nextInt();
								 orderService.validate(quantity);
								quantityFlag = true;
							} catch (InputMismatchException e) {
								quantityFlag = false;
								System.err.println("Cost should be in digits");
							}
						}while(!quantityFlag);
							
						
		              Order order1=new Order (Price,quantity);
		
		              
						int genearatedId =  orderService.addOrderService(order1);
			
		            	  System.out.println("The generated id is: " + genearatedId);
					
						break;
		              

						case 2:{
							try {
								if(order!=null)
								System.out.println("order details" + order);
							} catch (Exception e) {
								
								System.err.println("no details to display");
							}
							
						}break;
						case 3:{
							System.exit(0);
							System.out.println("thank u");
						}
						default:
						{
							flag=false;
							System.out.println("choice must be 1,2 and 3");
						}break;
						}
						do {
							scanner = new Scanner(System.in);
							System.out.println("do you want to continue again [yes/no]");
							continueChoice = scanner.nextLine();
							if (continueChoice.equalsIgnoreCase("yes")) {
								continueValue = false;
								flag=false;
								break;
							} else if (continueChoice.equalsIgnoreCase("no")) {
								System.out.println("thank you");
								continueValue = false;
								flag=true;
								break;
							} else {
								System.out.println("enter yes or no");
								continueValue = true;
								continue;
							}
						} while (continueValue);
					} catch (InputMismatchException e) {
						
						flag=true;
						System.out.println("choice must be in digits");
					}
				}while(!flag);
			
			}while(!flag);
}
}