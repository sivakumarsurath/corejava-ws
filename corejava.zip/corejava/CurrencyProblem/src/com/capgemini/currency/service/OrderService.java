package com.capgemini.currency.service;

import java.util.Currency;

import com.capgemini.currency.bean.Order;

public interface OrderService {

	void validate(int quantity);

	int addOrderService(Order order);

}
