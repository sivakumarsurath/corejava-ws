package com.capgemini.productmgmt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {

	static Map<String, String> productDetails;
	static Map<String, Integer> salesDetails;
	
	static {
		
		productDetails= new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
		
		
		salesDetails=new HashMap<>();
		salesDetails.put("lux",100);
		salesDetails.put("colgate",50);
		salesDetails.put("pears",70);
		salesDetails.put("sony",10000);
		salesDetails.put("samsung",23000);
		salesDetails.put("facepack",100);
		salesDetails.put("facecream",60);
	}

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		int update=0,rt;
		Iterator<String> iterator1=productDetails.keySet().iterator();
		

		while(iterator1.hasNext())
		{	String n1= iterator1.next();	String c1= productDetails.get(n1);
			
			if(c1.contentEquals(Category))
			{
			Iterator<String> iterator2= salesDetails.keySet().iterator();
			while(iterator2.hasNext())
			{
					String n2=iterator2.next();
				 rt=salesDetails.get(n2);
					
				if(n1.contentEquals(n2)) {
					
					update= ((rt*hike))/100+rt;
				
					salesDetails.put(n1,update);
			}}}
		
	          
				
	}
		return update;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return salesDetails;
	}
	@Override
	public Map getAllProducts(String Category, int hike) throws ProductException {
		
		return getSalesDetails();
	
	
	
			
				}

	public static Map<String, Integer> getSalesDetails() {
		return salesDetails;
	}

	public static void setSalesDetails(Map<String, Integer> salesDetails) {
		ProductDAO.salesDetails = salesDetails;
	}
	
}
