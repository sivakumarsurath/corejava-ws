package com.capgemini.productmgmt.ui;

import java.util.InputMismatchException;

import java.util.Map;
import java.util.Scanner;
import com.capgemini.productmgmt.exception.ProductException;
import comcapgemini.productmgmt.service.IProductService;
import comcapgemini.productmgmt.service.ProductServiceImpl;

/**
 * 
 * @author ssurath
 *
 */

public class Client {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		IProductService service = new ProductServiceImpl();

		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("*** welcome to the Application***");
			System.out.println("1.Update Product Price");
			System.out.println("2.Display Product Price");
			System.out.println("3.exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean ProductPriceFlag = false;
					int Product = 0;
					boolean ProductNameFlag = false;
					String ProductName = "";
					switch (choice) {

					case 1:

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Product name:");
							ProductName = scanner.nextLine();

							try {
								service.validateProductName(ProductName);
								ProductNameFlag = true;
							} catch (ProductException e) {
								ProductNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!ProductNameFlag);

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter the hike rate:");
							Product = scanner.nextInt();
							try {
								service.validateProduct(Product);
								ProductPriceFlag = true;
							} catch (ProductException e) {
								ProductPriceFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!ProductPriceFlag);

						String ProductCategory = "";
						boolean ProductCategoryFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter category of the Product :");
							try {

								ProductCategory = scanner.next();
								service.ProductCategory(ProductCategory);
								ProductCategoryFlag = true;
							} catch (InputMismatchException e) {
								ProductCategoryFlag = false;
								System.err.println("Enter a valid Input");
							} catch (ProductException e) {
								ProductCategoryFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!ProductCategoryFlag);

						break;

					case 2: {
						try {
							Map<String, Integer> productList = service.getProductDetails();
							System.out.println(productList);
						} catch (ProductException e) {

							System.err.println(e.getMessage());
						}

					}

						break;

					case 3:
						System.out.println("Thank u and have a nice day");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2 or 3");
						choiceFlag = false;
						break;
					}

				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}

}
