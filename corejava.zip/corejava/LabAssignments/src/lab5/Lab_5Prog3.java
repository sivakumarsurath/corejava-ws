package lab5;

import java.util.Scanner;

public class Lab_5Prog3 {
	public static void prime(int num) {
		int i, j, count;

		for (i = 1; i <= num; i++) {
			count = 0;
			for (j = 1; j <= i; j++) {

				if (i % j == 0) {
					count++;
				}

			}
			if (count == 2)
				System.out.println("prime number" + i);
		}

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a number:\n");
		int num = scanner.nextInt();
		prime(num);
		scanner.close();

	}

}
