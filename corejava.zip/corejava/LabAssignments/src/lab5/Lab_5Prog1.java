package lab5;

import java.util.Scanner;

public class Lab_5Prog1 {
	public void Signal(String n) {

		switch (n) {
		case "Yellow":
			System.out.println("Ready");
			break;
		case "Red":
			System.out.println("Stop");
			break;
		case "Green":
			System.out.println("Go");
			break;

		default:
			System.out.println("INVALID CHOICE");
			break;
		}

	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter your choice");
		String i = scanner.nextLine();

		 Lab_5Prog1 light = new  Lab_5Prog1();
		light.Signal(i);

	}

}
