package lab5;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Lab_5Prog6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		try {
			System.out.println("Enter Employee Salary");
			int age = scanner.nextInt();
			if (age < 3000) {
				throw new EmployeeException("Please enter a valid Salary");
			}

		} catch (EmployeeException ex) {

			System.out.println(ex.getMessage());
		}
	}
}
