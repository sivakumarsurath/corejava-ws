package lab1;

import java.util.Scanner;

public class Lab_1Prog4 {
	public boolean PowerO2(int n) {
		int j = 2;
		while (j < n) {
			j = j * 2;
		}
		if (j == n)
			return true;
		else
			return false;

	}

	public static void checkNumber(String[] args) {

		Scanner scanner = new Scanner(System.in);
		

		System.out.println("enter no");
		int c = scanner.nextInt();
		Lab_1Prog4 power = new Lab_1Prog4();
		boolean b = power.PowerO2(c);
		System.out.println(b);
		scanner.close();
	}

}
