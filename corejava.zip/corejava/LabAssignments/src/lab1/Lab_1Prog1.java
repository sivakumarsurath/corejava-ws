package lab1;

import java.util.Scanner;

public class Lab_1Prog1{ 
    public static int CalculateSum(int r) 
    { 
     int summ=0;
     for (int i = 1; i <=r; i++){
    	 if(i%3==0 || i%5==0)
    		 summ=summ+i;
    	 
     }
     return summ;}
    	 
    	 
    	 public static void main(String []args) 
    { 
    	  System.out.println("enter number");
  		Scanner scanner = new Scanner(System.in);
  		int range = scanner.nextInt();
  		Lab_1Prog1 natural=new Lab_1Prog1();
  		int Sum= natural.CalculateSum(range);
  		
  		System.out.println("sum is:" + Sum);
  		
  		scanner.close();
    } 
     } 

