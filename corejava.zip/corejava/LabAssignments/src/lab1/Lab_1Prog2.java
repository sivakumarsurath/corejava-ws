package lab1;

import java.util.Scanner;

public class Lab_1Prog2 {
	public void sum(int r) {
		int sum1 = 0;
		int sum2 = 0;
		for (int i = 1; i <= r; i++) {
			sum1 = sum1 + i * i;
		}

		for (int i = 1; i <= r; i++) {
			sum2 = sum2 + i;
		}

		int Caldiffer = sum1 - sum2;
		System.out.println(Caldiffer);
	}

	public static void main(String[] args) {

		System.out.println("ENTER NO");
		Lab_1Prog2 Caldiffer = new Lab_1Prog2();
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		Caldiffer.sum(a);
		scanner.close();
	}

}
