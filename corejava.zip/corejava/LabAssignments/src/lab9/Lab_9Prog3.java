package lab9;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class Lab_9Prog3 {

	private HashMap<Integer, Integer> getSquares(int[] a) {
		int b[] = new int[a.length];
		HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>();

		for (int i = 0; i < a.length; i++) {
			hash.put(a[i], a[i] * a[i]);
		}
		return hash;
	}

	public static void main(String[] args) {
		Lab_9Prog3 obj = new Lab_9Prog3();
		int size;

		Scanner sc = new Scanner(System.in);
		System.out.println("enter array size");
		size = sc.nextInt();
		int a[] = new int[size];
		for (int i = 0; i < size; i++) {

			a[i] = sc.nextInt();
		}
		HashMap<Integer, Integer> hs = new HashMap<Integer, Integer>();
		hs = obj.getSquares(a);
		System.out.println("direct hashmap");
		System.out.println(hs);
		System.out.println("key    value");
		for (Entry<Integer, Integer> entry : hs.entrySet()) {
			Integer key = entry.getKey();
			Integer value = entry.getValue();
			System.out.println(key + "       " + value);
			
		}

	}
}
