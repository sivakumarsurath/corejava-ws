package lab8;

import java.util.Scanner;

public class  Lab_8Prog7 {

	public boolean check(String name) {
		String word = "_job";
		boolean ans = true;
		int a = name.length();
		String s = name.substring(a - 4, a);
		System.out.println("string s:" + s);
		if (s.equals(word) && (a - 4) >= 8)
			ans = true;
		else
			ans = false;
		return ans;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter user name ");
		String name = sc.nextLine();
		Lab_8Prog7 obj = new Lab_8Prog7();
		boolean result = obj.check(name);
		if (result)
			System.out.println("username is valid");
		else
			System.out.println("username is invalid");

	}

}
