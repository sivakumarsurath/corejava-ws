package lab8;

import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;

    public class Lab_8Prog4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println(" enter path ");
		String file1 = scanner.nextLine();
		File file = new File(file1);
		System.out.println(file.exists() ? "file exists" : "file not exists");
		System.out.println(file.canRead() ? "file is readable" : "file is not readable");
		System.out.println(file.canWrite() ? "file is writable" : "file cannot be writable ");
		System.out.println(file1.length());

		StringTokenizer stringTokenizer = new StringTokenizer(file1, ".");
		while (stringTokenizer.hasMoreTokens()) {
			String ch = stringTokenizer.nextToken();
			System.out.println("type of file is : ." + stringTokenizer.nextToken());
		}
	}
}
