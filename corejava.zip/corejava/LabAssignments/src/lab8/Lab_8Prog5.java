package lab8;

import java.util.Arrays;
import java.util.Scanner;

public class Lab_8Prog5 {
	void checkString(String string) {
		char[] compare = string.toCharArray();
		char[] chaar = string.toCharArray();
		int flag = 1;
		Arrays.sort(chaar);

		if (compare == chaar)
			flag = 1;
		else
			flag = 0;

		if (flag == 0)
			System.out.println("string is  +ve");
		else
			System.out.println("string is not +ve");

	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter a string");
		Lab_8Prog5 obj = new Lab_8Prog5();
		String word = scanner.next();
		obj.checkString(word);
		scanner.close();
	}

}
