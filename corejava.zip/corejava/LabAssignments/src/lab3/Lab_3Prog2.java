package lab3;

import java.util.Scanner;

public class Lab_3Prog2 {
	public String convert(String a) {
		String result1, result2, result;
		int k;
		k = (a.length() / 2) + 1;
		result1 = a.substring(0, k);
		result1 = result1.toUpperCase();
		result2 = a.substring(k, a.length());
		result2 = result2.toLowerCase();
		result = result1 + result2;
		return result;

	}

	public static void main(String[] args) {

		Lab_3Prog2 obj = new Lab_3Prog2();
		String name;
		System.out.println("enter name");
		Scanner sr = new Scanner(System.in);
		name = sr.nextLine();
		System.out.println(obj.convert(name));
		

	}

}
