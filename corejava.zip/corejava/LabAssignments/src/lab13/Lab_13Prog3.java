package lab13;

public interface Lab_13Prog3 {
	boolean validate(String uname, String password);

}
