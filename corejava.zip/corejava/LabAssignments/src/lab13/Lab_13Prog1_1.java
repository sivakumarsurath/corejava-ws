package lab13;


	public interface Lab_13Prog1_1 {
	    int power(int a,int b);

	 

	}
	 


