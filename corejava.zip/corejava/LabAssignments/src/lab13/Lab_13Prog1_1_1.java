package lab13;

public class Lab_13Prog1_1_1 implements Lab_13Prog1_1 {

		 

	    public int power(int x, int y) {
	        return 0;
	        
	    }

	 

	}
	 

