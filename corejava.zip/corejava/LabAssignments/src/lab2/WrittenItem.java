package lab2;

abstract public class WrittenItem extends Item {
	private String author;

	public WrittenItem(String author) {
		super();
		this.author = author;
		System.out.println("'Inside Written item'");
	}

	@Override
	public void checkIn(int id) {
		System.out.println("The member with id " + id + "check in");

	}

	@Override
	public void checkOut(int id) {
		System.out.println("The member with id " + id + "check out");
		System.out.println("The member with id took book of " + author);
	}

}
