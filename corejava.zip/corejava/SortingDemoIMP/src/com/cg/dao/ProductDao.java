package com.cg.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.beans.Product;

public interface ProductDao {

	
	
	List<Product> getAllProducts();

	HashMap<Integer, Product> getallcugvf();
	
	
}
