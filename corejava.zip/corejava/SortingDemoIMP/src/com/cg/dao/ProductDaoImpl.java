package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.cg.beans.Product;
import com.cg.repository.ProductRepository;

public class ProductDaoImpl implements ProductDao {
ProductRepository repo= new ProductRepository();
	@Override
	public List<Product> getAllProducts() {

		HashMap<Integer, Product> map = ProductRepository.getAllProducts();
		Collection<Product> collection = map.values();

		List<Product> productlist = new ArrayList<>();
		productlist.addAll(collection);

		Collections.sort(productlist);

		return productlist;
	}

	@Override
	public HashMap<Integer, Product> getallcugvf() {
		// TODO Auto-generated method stub
		return repo.ggdhasm();
	}

}
