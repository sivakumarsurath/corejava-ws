package com.cg.presentation;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import com.cg.beans.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.service.Service;
import com.cg.service.ServiceImpl;
import com.cg.utility.SortById;
import com.cg.utility.SortByName;
import com.cg.utility.SortByPrice;

public class MainUi {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
	HashMap<Integer,Product> map1=new HashMap<>();
Service service=new ServiceImpl();
		b 
		List<Product> productlist = dao.getAllProducts();
		for (Product product : productlist) {

			System.out.println(product);
		}
		System.out.println("Enter option 1.SortByName\n2.SortByPrice\n3.SortById");
		int option = scanner.nextInt();
		switch (option) {

		case 1: {
			map1=service.getallcusto();
			SortByName sortByName= new SortByName();
			List<Product> productlistbyname = dao.getAllProducts();
			Collections.sort(productlistbyname,sortByName);
			display(productlistbyname);

		}
			break;
		case 2: {
			List<Product> productlistbyprice = dao.getAllProducts();
			Collections.sort(productlistbyprice, new SortByPrice());
			display(productlistbyprice);

		}
			break;
		case 3: {
			List<Product> productlistbyid = dao.getAllProducts();
			Collections.sort(productlistbyid, new SortById());
			display(productlistbyid);
			

		}
			break;
		}
	}
	        static void display(List<Product> productlist) {
		    for (Product product : productlist) {
			System.out.println(product);

		}

	}

}
