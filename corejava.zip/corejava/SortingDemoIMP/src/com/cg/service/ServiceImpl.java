package com.cg.service;

import java.util.HashMap;

import com.cg.beans.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;

public class ServiceImpl implements Service {
	ProductDao dao = new ProductDaoImpl();
	@Override
	public HashMap<Integer, Product> getallcusto() {
		// TODO Auto-generated method stub
		return dao.getallcugvf();
	}

}
