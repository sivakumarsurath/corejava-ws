package com.cg.utility;

import java.util.Comparator;

import com.cg.beans.Product;

public class Sort implements Comparator<Product> {

	@Override
	public int compare(Product arg0, Product arg1) {
		// TODO Auto-generated method stub
		return 0;
	}

}
