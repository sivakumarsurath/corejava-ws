import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileRW {

	/*public static void main(String[] args) {
		FileInputStream fin = null;
		FileOutputStream fout = null;
		int line,words,letters,count;
		try {
			fin = new FileInputStream("src/main/java/com/cg/App.java");
			fout = new FileOutputStream("src/main/java/my.doc");
			int i = 0;
			while (i != -1) {
				i = fin.read();}}
				
				if((char)i=='\n'){
						line++;}
				
				
			}
		System.out.println(count);}
		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
*/}