package com.cg.Demo;

public class StringDemo {

	
	
	
	
	public static void main(String[] args) {
	String s1="Hi";
	                                

	}

}
