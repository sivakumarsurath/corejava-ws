package com.capgemini;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DMLOperation {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultset = null;
	boolean status = false;
	int row = -1;
	Scanner scanner = new Scanner(System.in);
	private void create() {
        try {
            connection = DBConnection.getConnection();
            String query = "create table trainee(tid number(5) primary key," + "name varchar2(25),marks number(7,2))";
            statement = connection.prepareStatement(query);
            status = statement.execute();
            System.out.println("Table Created:" + status);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

	public void insert() {
		try {
			System.out.println("Enter tid,name,marks");
			int tid = scanner.nextInt();
			String name = scanner.next();
			double marks = scanner.nextDouble();

			connection = DBConnection.getConnection();

			statement = connection.prepareStatement("INSERT into trainee values(?,?,?)");
			statement.setInt(1, tid);
			statement.setString(2, name);
			statement.setDouble(3, marks);
			row = statement.executeUpdate();
			System.out.println(row + " inserted");

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	public void update() {

		try {
			System.out.println("Enter tid to update");
			int tid = scanner.nextInt();
			System.out.println("Enter the new marks");

			double marks = scanner.nextDouble();

			connection = DBConnection.getConnection();

			statement = connection.prepareStatement("update trainee set marks=? where tid=?");

			statement.setDouble(1, marks);
			statement.setInt(1, tid);

			row = statement.executeUpdate();
			System.out.println(row + " updated");

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public void delete() {

		try {
			System.out.println("Enter tid want to delete");
			int tid = scanner.nextInt();

			connection = DBConnection.getConnection();

			statement = connection.prepareStatement("delete from trainee where tid=?");

			statement.setInt(1, tid);

			row = statement.executeUpdate();
			System.out.println(row + " deleted");

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}}
/*
 * private void viewall() { connection = DBconnection.getConnection(); try {
 * statement = connection.prepareStatement("select * from trainee"); resultSet =
 * statement.executeQuery(); while (resultSet.next()) {
 * System.out.println(resultSet.getInt("tid") + "\t" +
 * resultSet.getString("name") + "\t" + resultSet.getDouble("marks")); } } catch
 * (SQLException e) { // TODO Auto-generated catch block e.printStackTrace(); }
 * } private void viewbyid() { // TODO Auto-generated method stub try {
 * System.out.println("Enter tid to view"); int tid = scanner.nextInt();
 * 
 * 
 * 
 * connection = DBconnection.getConnection();
 * 
 * 
 * 
 * statement =
 * connection.prepareStatement("select name,marks,tid from trainee where tid=?"
 * ); statement.setInt(1, tid); resultSet = statement.executeQuery(); if
 * (resultSet.next()) {System.out.println(resultSet.getInt("tid") + "\t" +
 * resultSet.getString("name") + "\t" + resultSet.getDouble("marks")); } row =
 * statement.executeUpdate(); System.out.println(row + "viewed"); } catch
 * (SQLException e) {
 * 
 * e.printStackTrace(); } } public static void main(String[] args) {
 * DMLOperation dml = new DMLOperation(); Scanner scanner = new
 * Scanner(System.in); System.out.
 * println("Enter 1.insert \n2.update \n3.delete \n4.viewall \n5.viewbyId"); int
 * option = scanner.nextInt(); switch (option) { case 1: dml.insert(); break;
 * case 2: dml.update(); break; case 3: dml.delete(); break; case 4:
 * dml.viewall(); case 5: dml.viewbyid(); default:
 * System.out.println("Enter 1 to 5 only"); }
 * 
 * } }
 */