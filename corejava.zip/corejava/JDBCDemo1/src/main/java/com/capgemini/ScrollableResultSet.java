package com.capgemini;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ScrollableResultSet {

	public static void main(String[] args) {

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement statement = connection.prepareStatement("" + "select * from emp",
						ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);) {
			{
				ResultSet resultSet = statement.executeQuery();
				System.out.println("Last row");
				resultSet.last();
				System.out.println(resultSet.getInt(1) + "" + resultSet.getString(2) + resultSet.getDouble("sal"));

				System.out.println("5th row");

				resultSet.absolute(5);
				System.out.println(resultSet.getInt(1) + "" + resultSet.getString(2) + resultSet.getDouble("sal"));

				System.out.println("1st row");
				resultSet.first();
				System.out.println(resultSet.getInt(1) + "" + resultSet.getString(2) + resultSet.getDouble("sal"));

				System.out.println("2nd row");
				resultSet.absolute(2);
				System.out.println(resultSet.getInt(1) + "" + resultSet.getString(2) + resultSet.getDouble("sal"));
				/*
				 * resultSet.updateDouble("sal", 8888); resultSet.(2);
				 * 
				 */

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
