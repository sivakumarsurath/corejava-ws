package com.capgemini.dbctest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.DBConnection;

public class DBConnectionTest {

	@Test
	 void testGetConnection() {
		assertNotNull(DBConnection.getConnection());
		
	}

}
