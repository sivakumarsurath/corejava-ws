package lab3;

public class Lab_3Prog4 {
}