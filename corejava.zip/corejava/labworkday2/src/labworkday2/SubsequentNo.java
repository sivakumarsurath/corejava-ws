package labworkday2;

import java.util.Scanner;

public class SubsequentNo {

	int reminder, result, i = 0;

	public int sub(int n) {

		while (n != 0) {
			reminder = n % 10;
			reminder++;

			n = n / 10;
			result = result + (reminder * (int) (Math.pow(10, i)));
			i++;
		}
		return result;
	}

	public static void main(String[] args) {
		SubsequentNo num = new SubsequentNo();
		System.out.println("enter number");
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		int count = num.sub(a);
		System.out.println("subsequent number:\n" + count);
		
		scanner.close();
	}

}
