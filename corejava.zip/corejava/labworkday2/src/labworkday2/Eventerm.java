package labworkday2;

import java.util.Scanner;

public class Eventerm {
	int count = 0, remi;

	public int EvenTerms(int n) {
		while (n != 0) {

			remi = n % 10;
			n = n / 10;
			if (remi % 2 == 0) {

				count = count + 1;
			}
		}
		return count;

	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter no");
		int c = scanner.nextInt();
		Eventerm evencount = new Eventerm();
		int count = evencount.EvenTerms(c);
		System.out.println(count);
		scanner.close();
	}
}
