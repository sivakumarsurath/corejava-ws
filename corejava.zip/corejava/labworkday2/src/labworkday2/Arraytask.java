package labworkday2;

import java.util.Scanner;

public class Arraytask {
	public static int[] reverseArrayElements(int array[]) {

		int j = 0, sum = 0, k = 0;
		int array1[] = new int[array.length];

		for (int i = 0; i < array.length; i++) {
			sum = 0;
			while (array[i] > 0) {
				k = array[i] % 10;
				sum = sum * 10 + k;
				array[i] = array[i] / 10;
			}
			array1[j] = sum;
			j++;

		}
		return array1;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("size");
		int size = scanner.nextInt();
		int array[] = new int[size];
		System.out.println("enter array elements");

		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
		int output[] = reverseArrayElements(array);

		for (int i = 0; i < array.length; i++) {
			System.out.println(output[i]);
			scanner.close();
		}

	}

}
